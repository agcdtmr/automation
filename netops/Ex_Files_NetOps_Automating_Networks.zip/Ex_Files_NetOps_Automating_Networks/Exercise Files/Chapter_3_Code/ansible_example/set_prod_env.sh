export hosts=all
export backup_directory=backup

