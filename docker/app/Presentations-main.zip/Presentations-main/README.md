# Presentations

👋 Hi! In this repo you can find all presentation materials from my talks and workshops! 

Folder | Presentation | Date | Speakers | Location | Event 
|:-------------------------- | :-------------------------- | :-------------------------- |:-------------------------- |:-------------------------- |:--------------------------|
docker-k8s-online-workshop| [Getting started with Containers and Kubernetes: A Beginner's Workshop](https://www.meetup.com/thenewitgirls/events/295157809/) | November 17, 2023 | Katharina Sick, Rigerta Demiri | Online | #theNewITGirls Tech Track | 
